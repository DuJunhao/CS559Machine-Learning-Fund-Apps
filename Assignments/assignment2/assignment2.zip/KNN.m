function relustLabel = KNN(test,sample,labels,k)
%
%   test is from training dataset, sample is the whole test dataset?labels
%   are identification.
%

[row , col] = size(sample);
differenceMatrix = repmat(test,[row,1]) - sample ;
distanceMatrix = sqrt(sum(differenceMatrix.^2,2));
[B , IX] = sort(distanceMatrix,'ascend');
len = min(k,length(B));
relustLabel = mode(labels(IX(1:len)));
end
